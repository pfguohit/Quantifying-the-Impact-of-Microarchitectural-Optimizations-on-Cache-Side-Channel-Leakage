#include <stdio.h>
#include "encoding.h"
#include "aes.h"
#include "rijndael-alg-fst.h"
#include "common.h"

static uint8_t __attribute__((aligned(L1DCACHE_LINE_SIZE * L1DCACHE_SET))) dummy_data[16 * L1DCACHE_SIZE * (EVICT_LOOP + 1)]; 
void main(void)
{
    uint8_t key[16] = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f};
    uint8_t plain_text[16] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00};
    uint8_t cipher_text[16]= {00};
    uint8_t plain_text_dec[16]= {00};

    volatile uint64_t time_start = 0, time_end = 0, time = 0;
    volatile uint32_t temp_data = 0;

    AES_KEY enc_key;
    AES_KEY dec_key;

    printf("test begin!\n");

    AES_set_encrypt_key(key, 128, &enc_key);
    
    for (uint32_t i = 40; i < (enc_key.rounds * 4 + 4); i++)
    {
        printf("enc_key[%d] = 0x%08x\n", i, enc_key.key[i]);
    }

    //AES_set_decrypt_key(key, 128, &dec_key);

    for (uint32_t enc_times = 0; enc_times < ENC_TIMES; enc_times++)
    {
        evict_cache((uint64_t)Te4, sizeof(Te4));
        AES_encrypt(plain_text, cipher_text, &enc_key);

        for (uint32_t i = 0; i < sizeof(Te4)/4; (i = i + READ_OFFSET))
        {
            time_start = rdcycle();
            temp_data = Te4[i];
            time_end = rdcycle();
            time = time_end - time_start;
            printf("%d\n", time);
        }
    
        for (uint32_t i = 0; i < sizeof(cipher_text); i++)
        {
            printf("%d\n", cipher_text[i]);
        }
        
        if(enc_times < 250)
        {
            plain_text[15]++;
        }
        else if((250 <= enc_times) && (enc_times < 500))
        {
            plain_text[14]++;
        }
        else if((500 <= enc_times) && (enc_times < 750))
        {
            plain_text[13]++;
        }
        else if((750 <= enc_times) && (enc_times < 1000))
        {
            plain_text[12]++;
        }
        
    }

    DEBUG_INFO("test end!\n");   
}


void evict_cache(uint64_t addr, uint64_t size){
    uint64_t num_sets_clear = size >> L1DCACHE_LINE_BIT;
    if((size & OFFSET_MASK) != 0){
        num_sets_clear += 1;
    }
    if((addr & OFFSET_MASK) != 0){
        num_sets_clear += 1;
    }
    if(num_sets_clear > L1DCACHE_SET){
        num_sets_clear = L1DCACHE_SET;
    }
    DEBUG_INFO("evict addr = 0x%x, size = 0x%x, num_sets_clear = %d\n", addr, size, num_sets_clear);
    volatile uint8_t dummy = 0x55;
    uint64_t aligned_mem = (((uint64_t)&dummy_data) + L1DCACHE_SIZE) & TAG_MASK;
    DEBUG_INFO("dummy_data addr = 0x%x, aligned_mem = 0x%x\n", &dummy_data, aligned_mem);
    for(uint64_t m = 0; m < num_sets_clear; ++m){
        uint64_t set_offset = (((addr & SET_MASK) >> L1DCACHE_LINE_BIT) + m) << L1DCACHE_LINE_BIT;
        //DEBUG_INFO("set_offset = %d\n", set_offset); 
        for(uint64_t n = 0; n < EVICT_LOOP * L1DCACHE_WAY ; ++n){
            uint64_t way_offset = n << (L1DCACHE_LINE_BIT + L1DCACHE_SET_BIT);
            //DEBUG_INFO("way_offset = %d\n", way_offset);
            dummy = *((uint8_t*)(aligned_mem + set_offset + way_offset));
            //DEBUG_INFO("evict addr= 0x%x, dummy = 0x%x\n", aligned_mem + set_offset + way_offset, dummy);
        }
    }

}