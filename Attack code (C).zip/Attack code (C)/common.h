
#ifndef COMMON_H
#define COMMON_H


//encryption times
#define ENC_TIMES 1000

//#define DEBUG
#ifdef DEBUG
#define DEBUG_INFO(format, ...) printf(format, ##__VA_ARGS__)
#else
#define DEBUG_INFO(format, ...) do { } while (0)
#endif

//replacement policy
// #define RANDOM_REPLACEMENT

#ifdef  RANDOM_REPLACEMENT
#define EVICT_LOOP 4
#else
#define EVICT_LOOP 1
#endif

//cache parameter
#define L1DCACHE_WAY 4  
#define L1DCACHE_LINE_SIZE 64
#define L1DCACHE_SET 64
#define L1DCACHE_SIZE (L1DCACHE_LINE_SIZE * L1DCACHE_SET * L1DCACHE_WAY)


#define L1DCACHE_LINE_BIT 6
#define L1DCACHE_SET_BIT 6
#define L1DCACHE_TAG_BIT (64 - L1DCACHE_LINE_BIT - L1DCACHE_SET_BIT)

#define FULL_MASK 0xFFFFFFFFFFFFFFFF
#define OFFSET_MASK (~(FULL_MASK << L1DCACHE_LINE_BIT))
#define TAG_MASK (FULL_MASK << (L1DCACHE_LINE_BIT + L1DCACHE_SET_BIT))
#define SET_MASK (~(TAG_MASK | OFFSET_MASK))

typedef unsigned char uint8_t;
typedef unsigned int uint32_t;
typedef unsigned long uint64_t;

void evict_cache(uint64_t addr, uint64_t size);
#define READ_OFFSET (L1DCACHE_LINE_SIZE/4)

#endif
